from endstone import ColorFormat
from endstone.event import event_handler, PlayerJoinEvent, PlayerChatEvent, PlayerQuitEvent, EventPriority
from endstone.plugin import Plugin

from .utils.profanity_utils import ProfanityCheck, ProfanityLonglist, ProfanityExtralist
pc = ProfanityCheck()
pl = ProfanityLonglist()
pe = ProfanityExtralist()
from .utils.detox_utils import detoxify_text, round_and_dict_to_list, is_toxic_text
from .utils.general_utils import to_hash_mask, split_into_tokens

from enum import Enum
from random import randint
import os, time, asyncio, inspect, importlib.util, sys, threading
from collections import defaultdict
from pathlib import Path

def is_kherimoya_environment() -> bool: # simply checks if the four folders Kherimoya makes upon creating a server are present. The reason why we check for JUST the folders, is so that people can make Kherimoya-like environments by just making the folders themselves.
    kherimoyapaths = ['../state','../server','../extra','../config']
    for path_str in kherimoyapaths:
        if not Path(path_str).is_dir():
            return False
    return True

class PlayerDataManager:
    def __init__(self):
        self.playerdata = defaultdict(lambda: {
            "latest_time_a_message_was_sent": time.monotonic() - 10,  # Allow immediate first message
            "last_message": ""
        })
    
    def update_player_data(self, name, message):
        self.playerdata[name]["latest_time_a_message_was_sent"] = time.monotonic()
        self.playerdata[name]["last_message"] = message

    def get_player_data(self, name):
        return self.playerdata[name]

    def remove_player_data(self, name):
        if name in self.playerdata:
            del self.playerdata[name]

class BreezeTextProcessing:
    def check_and_censor(self, text: str, checks: dict | None = None) -> tuple[str, bool, list]:
        finishedmessage = text
        defaults = {
            "Detoxify": True,
            "Profanity-check": True,
            "Extralist": True,
            "Longlist": True,
        }
        if checks is not None:
            checks = {**defaults, **checks}
        else:
            checks = defaults
    

        caught = []
        isbad = False

        # detoxify
        if is_toxic_text(round_and_dict_to_list(detoxify_text(text, 'multilingual'))) and checks["Detoxify"]:
            isbad = True
            caught.append("Detoxify")
            finishedmessage = to_hash_mask(text)

            return (finishedmessage, isbad, caught) # returns as the finished message is just a hash mask of the original.
        
        # profanity check
        if pc.is_profane(text) and checks["Profanity-check"]:
            isbad = True
            caught.append("Profanity-check")

            finishedmessage = pc.censor(finishedmessage, neighbors=2, window_size=1)
                
        # profanity extralist
        if pe.is_profane(text) and checks["Extralist"]:
            isbad = True
            caught.append("Extralist")

            finishedmessage = pe.censor(finishedmessage, neighbors=2)
            
        # profanity longlist
        if pl.is_profane(text) and checks["Longlist"]:
            isbad = True
            caught.append("Longlist")

            finishedmessage = pl.censor(finishedmessage, neighbors=1)

        return (finishedmessage, isbad, caught)

class BreezeModuleManager():
    class HandlerState(Enum):
            NONE = 0
            DEFAULT = 1
            CUSTOM = 2

    def __init__(self, logger: Plugin.logger, useCWDforExtra=False): # when useCWDforExtra is true, the path will resolve to "$CWD/extra/breeze/". This allows for non-Kherimoya environments to still use Breeze's extra features, but won't sync if the CWD is different every time.
        self._isKherimoya = is_kherimoya_environment()
        self.useCWDforExtra = useCWDforExtra
        self.isBreezeInstalled = False # by "installed", we mean if the extra/breeze/ folder exists. This is used to check if it's "safe" to do something in there.
        self.breezeInstallationPath = None # path to the breeze installation (extra/breeze/)
        self.extensionFiles = [] # list of extension files found in extra/breeze/extensions/
        self.logger = logger # logger from the main plugin
        
        self.handlerstate = self.HandlerState.NONE
        self.handler = None

    def _defaulthandler(self, plugin:Plugin, event:PlayerChatEvent): # the default "handler" function that Breeze will use on message management. 
        plugin.bea.on_breeze_chat_event(event, plugin)

        sender_uuid = str(event.player.unique_id)
        finishedmessage = event.message # <-- not sure if we should keep it as the original message or not, but for safety, but we do as it's easier

        event.cancel()

        localplayerdata = plugin.pdm.get_player_data(event.player.name)
        isbad = None
        fullycancelmessage = (False, "") # 1= if to fully cancel, 2= reason (fluent)
        caught = [] # what catches the message, if caught. so if it's caught by the extralist, it'll contain "Extralist"
        shouldcheckmessage = True # if false, skip all checks with everything or other things
        worthytolog = False # if true, log the message as "worthy" to the console (and in the future) to discord, meaning it wasn't caught by anything

        # spam check
        if time.monotonic() - localplayerdata["latest_time_a_message_was_sent"] < 0.5: # within HALF a second of other message
            fullycancelmessage = (True, "spam, gave displayed cancel")
            shouldcheckmessage = False
            event.player.send_message("You're sending messages too fast!")

        if fullycancelmessage[0]:
            shouldcheckmessage = False
        
        if shouldcheckmessage: 
            finishedmessage, isbad, caught = plugin.btp.check_and_censor(event.message)

        # finally, after checking send the message and some extra stuff
        if isbad:
            worthytolog = True

        if not fullycancelmessage[0]: # if not fully canceling the message
            plugin.server.broadcast_message(f"<{event.player.name}> {finishedmessage}")
        else: #usually, cancelled messages are useless spam that clogs up the logs, but sometimes they may actually be harmful
            if randint(1, 3) == 1: # there's no easy way to find out if it's harmful or not, so we gamble for it
                worthytolog = True

        plugin.pdm.update_player_data(event.player.name, event.message)

        plugin.bea.on_breeze_chat_processed(event, {
            "isbad": isbad,
            "fullycancelmessage": fullycancelmessage,
            "shouldcheckmessage": shouldcheckmessage,
            "caught": caught,
            "finishedmessage": finishedmessage,
            "worthytolog": worthytolog,
            "sender_uuid": sender_uuid,
            "sender_name": event.player.name,
            "original_message": event.message
        }, isbad, plugin)
        
        if worthytolog:
            plugin.logger.info(f"""\n
    --- BREEZE LOG OF MESSAGE FROM {sender_uuid} / {event.player.name} ---
    message
    | isbad = {ColorFormat.BLUE}{isbad}{ColorFormat.RESET}
    | fullycancelmessage = {ColorFormat.BLUE}{fullycancelmessage}{ColorFormat.RESET}
    | shouldcheckmessage = {ColorFormat.BLUE}{shouldcheckmessage}{ColorFormat.RESET}

    censoring
    | tokens = {ColorFormat.BLUE}{split_into_tokens(event.message)}{ColorFormat.RESET}
    | caught = {ColorFormat.BLUE}{caught}{ColorFormat.RESET}
    
    input) {ColorFormat.BLUE}{event.message}{ColorFormat.RESET}
    output) {ColorFormat.BLUE}{finishedmessage}{ColorFormat.RESET}\n
    --- END OF LOG ---
        """)
            
    def _initializekherimoya(self): # create the extra/breeze/ folder and its contents if it does not exist AND if we're in a Kherimoya(-like) environment
        if self._isKherimoya: # check if we're in a kherimoya-like environment
            path_str = "../extra/breeze/"
            self.breezeInstallationPath = Path(path_str).resolve() # assign path first
            
            if not Path(path_str).is_dir(): # check if it's installed
                os.makedirs(Path(path_str) / "extensions", exist_ok=True)
                self.isBreezeInstalled = True
            else:
                self.isBreezeInstalled = True
                
            print(f"{ColorFormat.LIGHT_PURPLE}Breeze was installed from the Kherimoya path: {path_str}. REMEMBER THIS!!")
        elif self.useCWDforExtra:
            cwdextrapathstr = "./extra/breeze/"
            if not Path(cwdextrapathstr).is_dir(): # check if it's installed
                if Path(os.getcwd()) == Path.home():
                    self.logger.warning("BreezeModuleManager: Hey! You're running the server from your home directory, so Breeze will not create the extra/breeze/ folder here for safety reasons. Please run the server from a different directory if you want to use Breeze's extra features.")
                    return # safety check to prevent creating folders in the user's home directory if they run the server from there
                os.makedirs(Path(cwdextrapathstr) / "extensions", exist_ok=True)
                self.isBreezeInstalled = True
            else:
                self.isBreezeInstalled = True
    
            self.breezeInstallationPath = Path(cwdextrapathstr).resolve() # Assign path before printing
            self.logger.info(f"{ColorFormat.LIGHT_PURPLE}Breeze was installed from the CWD path: {self.breezeInstallationPath}. REMEMBER THIS!!")
        
        if self.isBreezeInstalled:
            pass # do something like create default config files, later on
        else:
            self.logger.error("BreezeModuleManager: We're likely not in a Kherimoya-like environment, so extensions and other stuff will not be loaded.")

    def _findextensions(self): # find extensions in extra/breeze/extensions, also checks for a handler and assigns self.handler to the handler function.
        if self.isBreezeInstalled:
            extensions_path = self.breezeInstallationPath / "extensions"
            extension_files = [f for f in os.listdir(extensions_path) if Path(f).suffix == ".py"]

            if "handler.py" in extension_files:
                module_name = "handler"
                handler_path = extensions_path / "handler.py"
                handlerfunc = None
                extension_files.remove("handler.py") # remove it so on extension loading, the handler won't be loaded like an extensions

                self.logger.info(f"[BreezeModuleManager] Found a custom handler...")

                spec = importlib.util.spec_from_file_location(module_name, handler_path)
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)

                # function inside handler.py should be named "handler" or whatever you expect
                handlerfunc = getattr(module, "handler", None)

                extension_files.remove("handler.py")

                if handlerfunc is None:
                    self.logger.warning("[BreezeModuleManager] Custom handler found but no 'handler' function defined. Falling back to the default handler.")
                    self.handlerstate = self.HandlerState.NONE
                    self.handler = self._defaulthandler
                else:
                    self.logger.info("[BreezeModuleManager] The custom handler will now override Breeze's default handler.")
                    self.handlerstate = self.HandlerState.CUSTOM
                    self.handler = handlerfunc
            else:
                self.handler = self._defaulthandler
                self.handlerstate = self.HandlerState.DEFAULT

            self.logger.info(f"[BreezeModuleManager] Found {len(extension_files)} extensions in {extensions_path}: {extension_files}")
            # later on, we can load these extensions dynamically
            self.extensionFiles = extension_files

    def _loadextension(self, extension_filename: str):
        if not self.isBreezeInstalled:
            self.logger.warning("BreezeModuleManager: Cannot load extension because Breeze is not installed.")
            return
    
        ext_path = self.breezeInstallationPath / "extensions" / extension_filename
        if not ext_path.is_file():
            self.logger.error(f"BreezeModuleManager: Extension file not found: {ext_path}")
            return

        module_name = extension_filename.removesuffix(".py")

        try:
            spec = importlib.util.spec_from_file_location(module_name, str(ext_path))
            if spec is None or spec.loader is None:
                self.logger.error(f"BreezeModuleManager: Failed to create spec for {module_name}")
                return

            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module  
            spec.loader.exec_module(module)
            self.logger.info(f"BreezeModuleManager: Loaded extension module: {module_name}")

            if hasattr(module, "on_load"):
                try:
                    module.on_load(BreezeExtensionAPI(self.logger))
                    self.logger.info(f"BreezeModuleManager: Extension {module_name} initialized via on_load()")
                except Exception as e:
                    self.logger.error(f"BreezeModuleManager: Error in on_load() of {module_name}: {e}")
            else:
                self.logger.warning(f"BreezeModuleManager: Extension {module_name} has no on_load() function.")

        except Exception as e:
            self.logger.error(f"BreezeModuleManager: Failed to load extension {extension_filename}: {e}")

    def start(self): # called by the main plugin to start the module manager
        self._initializekherimoya()

        # Extensions
        if self.isBreezeInstalled:
            self._findextensions()
            for extension_file in self.extensionFiles:
                self.logger.info(f"[BreezeModuleManager] Loading extension: {extension_file}")
                self._loadextension(extension_file)
        else:
            self.logger.error("[BreezeModuleManager] Features like extensions will NOT be loaded because Breeze is not installed.")

        # Handler
        if self.handlerstate == self.HandlerState.NONE:
            self.logger.warn("[BreezeModuleManager] No handler was loaded! Loading in the default handler instead...")
            self.handlerstate = self.HandlerState.DEFAULT

        if self.handlerstate == self.HandlerState.DEFAULT:
            self.logger.info("[BreezeModuleManager] We're using Breeze's basic, default handler...")
        else: # if it's a custom one
            self.logger.info 

class BreezeExtensionAPI(): # For extensions to use to interact with Breeze
    class _EventBus():
        def __init__(self, logger: Plugin.logger):
            self.listeners = {}
            self.logger = logger

        def on(self, event_name, func):
            self.listeners.setdefault(event_name, []).append(func)

        def _emit(self, event_name, *args, **kwargs):
            for func in list(self.listeners.get(event_name, [])):
                try:
                    if inspect.iscoroutinefunction(func):
                        asyncio.run(func(*args, **kwargs))
                    else:
                        func(*args, **kwargs)
                except Exception as e:
                    self.logger.error(f"Error in event listener for {event_name}: {e}")
                self.logger.info(f"[BreezeExtensionAPI] Emitted to {str(func)}")
    
    def __init__(self, logger: Plugin.logger):
        self.plugin = None # set to the main Breeze plugin instance later on
        self.ready = False # false if it's not ready yet
        self.logger = logger

        self._eventbus = self._EventBus(logger) # private because extensions should just BreezeExtensionAPI.eventbus

    @property
    def eventbus(self):
        return self._eventbus

    def on_breeze_chat_event(self, event:PlayerChatEvent, plugin):
        """Called when a chat event is processed by Breeze. 
        
        Extensions can hook into this to do extra functions but they can NOT modify management."""
        if not self.ready:
            return

        self._eventbus._emit("on_breeze_chat_event", event, plugin); self.logger.info("[BreezeExtensionAPI] on_breeze_chat_event")

        return event, plugin
        
    def on_breeze_chat_processed(self, event:PlayerChatEvent, handler, isbad:bool, plugin:Plugin):
        """Called after Breeze has processed a chat event. Breeze is a dictionary of values from Breeze's message evaluation and stuff. 
        
        Extensions can hook into this to do extra functions but they can NOT modify management."""
        if not self.ready:
            return

        self._eventbus._emit("on_breeze_chat_processed", event, handler, isbad, plugin); self.logger.info("[BreezeExtensionAPI] on_breeze_chat_processed")

        return event, handler, isbad, plugin

    def initialize(self, plugin_instance: Plugin):
        self.plugin = plugin_instance
        self.ready = True

class Breeze(Plugin): #PLUGIN
    def on_enable(self) -> None:
        self.logger.info("Enabling Breeze")
        self.register_events(self) # "By calling self.register_events, Endstone will look into the object that is passed in as the argument and register all handlers with an @event_handler decorator to the event system."
        current_directory = os.getcwd()
        self.server.logger.info(f"{current_directory}, {__file__}")

        self.logger.info('extensionapiing'); self.bea = BreezeExtensionAPI(self.logger); self.bea.initialize(self)

        self.logger.info('modulemanagering'); self.bmm = BreezeModuleManager(logger=self.logger); self.bmm.start()

        self.isKherimoya = is_kherimoya_environment()
        if self.isKherimoya:
            self.logger.info("Kherimoya-like environment detected!! Things like extensions, settings, and stuff is now available")
        else:
            self.logger.info("Standard Endstone environment detected! Only basic text chat will be available...")

    def __init__(self): # 
        super().__init__()
        self.pdm = PlayerDataManager()
        self.btp = BreezeTextProcessing()

    def handle(self, event):
        if not self.bmm.handler == None: # if it's not none, then it's safe to use this (hopefully)
            try:
                self.bmm.handler(plugin=self, event=event)
            except Exception as e:
                self.logger.error(f"Exception while handling message, falling back to default handler: {e}")
                self.bmm._defaulthandler(plugin=self, event=event)

    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent):
        player = event.player
        self.pdm.remove_player_data(player.name)

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent):
        pdata = self.pdm.get_player_data(event.player.name)
        pdata["latest_time_a_message_was_sent"] = time.monotonic() - 10 # set their clock in the past so they can message immediately
        pdata["last_message"] = ""
      
    @event_handler(priority=EventPriority(1))
    def on_chat_sent_by_player(self, event: PlayerChatEvent): # chat manager
        threading.Thread(target=self.handle, args=(event,)).start() # handle using the handler bmm gave us