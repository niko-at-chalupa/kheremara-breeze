from utils.detox_utils import detoxify_text, round_and_dict_to_list, is_toxic_text

from utils.profanity_utils import ProfanityCheck, ProfanityLonglist, ProfanityExtralist
pc = ProfanityCheck()
pl = ProfanityLonglist()
pe = ProfanityExtralist()

from utils.general_utils import to_hash_mask, split_into_tokens
from random import randint
from rich import print as printr

def check_and_censor(text: str, checks: dict | None = None) -> tuple[str, bool, list]:
        finishedmessage = text
        defaults = {
            "Detoxify": True,
            "Profanity-check": True,
            "Extralist": True,
            "Longlist": True,
        }
        if checks is not None:
            checks = {**defaults, **checks}
        else:
            checks = defaults
    

        caught = []
        isbad = False

        if is_toxic_text(round_and_dict_to_list(detoxify_text(text))) and checks["Detoxify"]:
            isbad = True
            caught.append("Detoxify")
            finishedmessage = to_hash_mask(text)

            return (finishedmessage, isbad, caught)
        

        
        if pc.is_profane(text) and checks["Profanity-check"]:
            isbad = True
            caught.append("Profanity-check")

            finishedmessage = pc.censor(finishedmessage, neighbors=2, window_size=1)
                
        if pe.is_profane(text) and checks["Extralist"]:
            isbad = True
            caught.append("Extralist")

            finishedmessage = pe.censor(finishedmessage, neighbors=2)
            
        if pl.is_profane(text) and checks["Longlist"]:
            isbad = True
            caught.append("Longlist")

            finishedmessage = pl.censor(finishedmessage, neighbors=1)

        tokens = split_into_tokens(text); tokens = [t.lower() for t in tokens]
        printr(f"\n[blue]TOKENS) {tokens}\n")
        
        return (finishedmessage, isbad, caught)

while True:
    finishedmessage, isbad, caught = check_and_censor(input('> '), {"Detoxify": False})

    if isbad:
        printr(f"[red]Flagged, caught by [purple]{caught}\n")
    else:
        printr(f"[green]Passed\n")
    printr(f"[blue]OUTPUT) {finishedmessage}")

    


