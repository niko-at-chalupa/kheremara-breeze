from endstone import ColorFormat
from endstone.event import event_handler, PlayerJoinEvent, PlayerChatEvent, PlayerQuitEvent
from endstone.plugin import Plugin

from .utils.profanity_utils import ProfanityCheck, ProfanityLonglist, ProfanityExtralist
pc = ProfanityCheck()
pl = ProfanityLonglist()
pe = ProfanityExtralist()
from .utils.detox_utils import detoxify_text, round_and_dict_to_list, is_toxic_text
from .utils.general_utils import to_hash_mask, split_into_tokens

from random import randint
import os
from collections import defaultdict
import time

class PlayerDataManager:
    def __init__(self):
        self.playerdata = defaultdict(lambda: {
            "latest_time_a_message_was_sent": time.monotonic() - 10,  # Allow immediate first message
            "last_message": ""
        })
    
    def update_player_data(self, name, message):
        self.playerdata[name]["latest_time_a_message_was_sent"] = time.monotonic()
        self.playerdata[name]["last_message"] = message

    def get_player_data(self, name):
        return self.playerdata[name]

    def remove_player_data(self, name):
        if name in self.playerdata:
            del self.playerdata[name]

class BreezeProfanityFilter:
    def check_and_censor(self, text: str, checks: dict | None = None) -> tuple[str, bool, list]:
        finishedmessage = text
        defaults = {
            "Detoxify": True,
            "Profanity-check": True,
            "Extralist": True,
            "Longlist": True,
        }
        if checks is not None:
            checks = {**defaults, **checks}
        else:
            checks = defaults
    

        caught = []
        isbad = False

        # Detoxify -- Special, slow, but really important. Runs first, as if it's detected, we just return the hashmask and return
        if is_toxic_text(round_and_dict_to_list(detoxify_text(text))) and checks["Detoxify"]:
            isbad = True
            caught.append("Detoxify")
            finishedmessage = to_hash_mask(text)

            return (finishedmessage, isbad, caught)
        

        
        # profanity check
        if pc.is_profane(text) and checks["Profanity-check"]:
            isbad = True
            caught.append("Profanity-check")

            finishedmessage = pc.censor(finishedmessage, neighbors=2, window_size=1)
                
        # profanity extralist
        if pe.is_profane(text) and checks["Extralist"]:
            isbad = True
            caught.append("Extralist")

            finishedmessage = pe.censor(finishedmessage, neighbors=2)
            
        # profanity longlist
        if pl.is_profane(text) and checks["Longlist"]:
            isbad = True
            caught.append("Longlist")

            finishedmessage = pl.censor(finishedmessage, neighbors=1)

        return (finishedmessage, isbad, caught)

class Breeze(Plugin): #PLUGIN
    def on_enable(self) -> None:
        self.logger.info("on_enable is called!")
        self.register_events(self) # "By calling self.register_events, Endstone will look into the object that is passed in as the argument and register all handlers with an @event_handler decorator to the event system."
        current_directory = os.getcwd()
        self.server.logger.info(current_directory)

    def __init__(self):
        super().__init__()
        self.player_data_manager = PlayerDataManager()
        self.breeze_profanity_filter = BreezeProfanityFilter()

    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent):
        player = event.player
        self.player_data_manager.remove_player_data(player.name)

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent):
        # Set the last message time far enough in the past to allow immediate chat
        pdata = self.player_data_manager.get_player_data(event.player.name)
        pdata["latest_time_a_message_was_sent"] = time.monotonic() - 10
        pdata["last_message"] = ""
      
    @event_handler 
    def on_chat_sent_by_player(self, event: PlayerChatEvent): # chat manager
        sender_uuid = str(event.player.unique_id)
        finishedmessage = event.message  # <-- Fix here

        event.cancel()

        localplayerdata = self.player_data_manager.get_player_data(event.player.name)
        isbad = None
        fullycancelmessage = (False, "") # 1= if to fully cancel, 2= reason
        caught = [] # what catches the message, if caught. so if it's caught by the extralist, it'll contain "Extralist"
        shouldcheckmessage = True # if false, skip all checks with Veil, or other things
        worthytolog = False # if true, log the message as "worthy" to the console (and in the future) to discord, meaning it wasn't caught by anything

        # spam check
        if time.monotonic() - localplayerdata["latest_time_a_message_was_sent"] < 3: # within three second of other message
            fullycancelmessage = (True, "spam, gave displayed cancel")
            shouldcheckmessage = False
            event.player.send_message("You're sending messages too fast!")

        if fullycancelmessage[0]:
            shouldcheckmessage = False
        
        if shouldcheckmessage: 
            finishedmessage, isbad, caught = self.breeze_profanity_filter.check_and_censor(event.message)

        # finally, after checking send the message and some extra stuff
        if isbad:
            worthytolog = True

        if not fullycancelmessage[0]: # if not fully canceling the message
            self.server.broadcast_message(f"<{event.player.name}> {finishedmessage}")
        else:
            if randint(1, 3) == 1:
                worthytolog = True

        self.player_data_manager.update_player_data(event.player.name, event.message)
        
        if worthytolog:
            self.logger.info(f"""\n
    --- BREEZE LOG OF MESSAGE FROM {sender_uuid} / {event.player.name} ---
    message
    | isbad = {ColorFormat.BLUE}{isbad}{ColorFormat.RESET}
    | fullycancelmessage = {ColorFormat.BLUE}{fullycancelmessage}{ColorFormat.RESET}
    | caught = {ColorFormat.BLUE}{caught}{ColorFormat.RESET}
    | shouldcheckmessage = {ColorFormat.BLUE}{shouldcheckmessage}{ColorFormat.RESET}

    veil
    | tokens = {ColorFormat.BLUE}{split_into_tokens(event.message)}{ColorFormat.RESET}
    
    input) {ColorFormat.BLUE}{event.message}{ColorFormat.RESET}
    output) {ColorFormat.BLUE}{finishedmessage}{ColorFormat.RESET}\n
    --- END OF LOG ---
        """)